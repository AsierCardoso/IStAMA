package Modelo;

public class Ladrillo0 extends Ladrillo{

	public Ladrillo0() {
		super(0);
		
	}
	
	
	
	

}
