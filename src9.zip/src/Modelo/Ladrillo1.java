
	package Modelo;

	public class Ladrillo1 extends Ladrillo{

		public Ladrillo1() {
			super(1);
			
		}
		
		
		
		

	}


