package Modelo;

public class Ladrillo2 extends Ladrillo{

	public Ladrillo2() {
		super(2);
		
	}
	
	
	
	

}