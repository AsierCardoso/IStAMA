package Modelo;

public class Ladrillo3 extends Ladrillo{

	public Ladrillo3() {
		super(3);
		
	}
	
	
	
	

}